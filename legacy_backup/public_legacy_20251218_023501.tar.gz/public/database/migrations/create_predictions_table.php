<?php

use Illuminate\Database\Capsule\Manager as Capsule;

class CreatePredictionsTable
{
    public function up()
    {
        if (!Capsule::schema()->hasTable('predictions')) {
            Capsule::schema()->create('predictions', function ($table) {
                $table->increments('prediction_id');
                $table->integer('user_id')->unsigned();
                $table->integer('stock_id')->unsigned();
                $table->enum('prediction_type', ['Bullish', 'Bearish']);
                $table->decimal('target_price', 10, 2)->nullable();
                $table->timestamp('prediction_date')->useCurrent();
                $table->timestamp('end_date')->nullable();
                $table->boolean('is_active')->default(true);
                $table->decimal('accuracy', 5, 2)->nullable();
                $table->text('reasoning')->nullable();
                
                $table->foreign('user_id')
                      ->references('id')
                      ->on('users')
                      ->onDelete('cascade');
                      
                $table->foreign('stock_id')
                      ->references('stock_id')
                      ->on('stocks')
                      ->onDelete('cascade');
            });
            
            echo "Predictions table created successfully!\n";
        } else {
            echo "Predictions table already exists!\n";
        }
    }

    public function down()
    {
        if (Capsule::schema()->hasTable('predictions')) {
            Capsule::schema()->drop('predictions');
            echo "Predictions table dropped successfully!\n";
        } else {
            echo "Predictions table does not exist!\n";
        }
    }
}